package com.weighted;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class WeightedGraph<T> {
    private boolean undirected;
    private List<Vertex<T>> vertices = new ArrayList<>();

    WeightedGraph(boolean undirected) {
        this.undirected = undirected;
    }

    public void addVertex(Vertex<T> vertex) {
        vertices.add(vertex);
    }

    public void addEdge(Vertex<T> destinationFrom, Vertex<T> destinationTo, double weight) {
        if (!hasVertex(destinationFrom)) {
            addVertex(destinationFrom);
        }

        if (!hasVertex(destinationTo)) {
            addVertex(destinationTo);
        }

        if (hasEdge(destinationFrom, destinationTo) || destinationFrom.equals(destinationTo)) {
            return;
        }

        if (undirected) {
            vertices.forEach(element -> {
                if (element.equals(destinationFrom) && !hasEdge(destinationFrom, destinationTo)) {
                    element.addAdjacentVertex(destinationTo, weight);
                }
                if (element.equals(destinationTo) && !hasEdge(destinationTo, destinationFrom)) {
                    element.addAdjacentVertex(destinationFrom, weight);
                }
            });
        } else {
            vertices.stream().filter(element -> element.getData().equals(destinationFrom)
                    && !hasEdge(destinationFrom, destinationTo))
                    .forEachOrdered(element -> element.addAdjacentVertex(destinationTo, weight));
        }

    }

    public boolean hasVertex(Vertex<T> vertex) {
        return vertices.stream().anyMatch(element -> element.getData().equals(vertex.getData()));
    }

    public boolean hasEdge(Vertex<T> destinationFrom, Vertex<T> destinationTo) {
        if (!hasVertex(destinationFrom)) {
            return false;
        }

        return vertices.stream().filter(element -> element.getData().equals(destinationFrom) && element.getAdjacentVertices() != null).flatMap(element -> element.getAdjacentVertices().keySet().stream()).anyMatch(elementVertex -> elementVertex.getData().equals(destinationTo));
    }

    public int getEdgesCount() {
        int count = vertices.stream().mapToInt(vertex -> vertex.getAdjacentVertices().size()).sum();

        if (undirected) {
            count /= 2;
        }

        return count;
    }

    public List<Vertex<T>> adjacencyList(Vertex<T> vertex) {
        if (!hasVertex(vertex)) {
            return null;
        }

        List<Vertex<T>> vertices = new LinkedList<>();

        this.vertices.stream()
                .filter(element -> element.getData().equals(vertex.getData()))
                .findFirst()
                .ifPresent(element -> vertices.addAll(element.getAdjacentVertices().keySet()));

        return vertices;
    }

    public Map<Vertex<T>, Double> getEdges(Vertex<T> vertex) {
        if (!hasVertex(vertex)) {
            return null;
        }

        return vertices.stream().filter(element -> element.getData().equals(vertex.getData())).findFirst().map(Vertex::getAdjacentVertices).orElse(null);

    }
}
