package com.assignment.application;

import com.assignment.heap.MyHeap;
import com.assignment.queue.MyQueue;
import com.assignment.stack.MyStack;

public class Main {
    public static void main(String[] args) {
        MyStack<Integer> myStack = new MyStack<>();

        System.out.println("Pushing elements into Stack...");
        myStack.push(1);
        myStack.push(2);
        myStack.push(10);
        myStack.push(4);

        myStack.printStack();

        System.out.println("Calling peek() method: " + myStack.peek());
        myStack.pop();
        System.out.println("Calling peek() method after pop(): " + myStack.peek());
        System.out.println();

        MyQueue<Integer> myQueue = new MyQueue<>();

        myQueue.enqueue(5);
        myQueue.enqueue(10);
        myQueue.enqueue(20);
        myQueue.enqueue(30);
        myQueue.enqueue(40);
        System.out.println("Queue elements: ");
        myQueue.printQueue();

        myQueue.dequeue();

        System.out.println("Queue elements after dequeue: ");
        myQueue.printQueue();

        MyHeap<Integer> myHeap = new MyHeap<>();

        myHeap.add(1);
        myHeap.add(2);
        myHeap.add(3);
        myHeap.add(4);

        myHeap.removeRoot();

        System.out.println();
    }
}
