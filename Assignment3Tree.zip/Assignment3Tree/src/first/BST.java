package first;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Stack;

public class BST<K extends Comparable<K>, V> {
    private Node root;

    private class Node {
        private K key;
        private V val;
        private Node left, right;

        public Node(K key, V val) {
            this.key = key;
            this.val = val;
        }
    }

    public void put(K key, V val) {
        if (get(key) != null) return;

        root = insertRecursively(root, key, val);
    }

    Node insertRecursively(Node root, K key, V val) {
        if (root == null) { return new Node(key, val); }
        if (key.compareTo(root.key) < 0) { root.left = insertRecursively(root.left, key, val); }
        else { root.right = insertRecursively(root.right, key, val); }

        return root;
    }


    public V get(K key) {
        Node curr = root;

        while (curr != null && !curr.key.equals(key)) {
            if (key.compareTo(curr.key) < 0) {
                curr = curr.left;
            } else {
                curr = curr.right;
            }
        }

        return curr != null ? curr.val : null;
    }

    public void delete(K key) {
        boolean isInLeft = false;
        Node current = root;
        Node parent = root;

        while (current.key != key) {
            parent = current;

            if (current.key.compareTo(key) > 0) {
                isInLeft = true;
                current = current.left;
            } else {
                isInLeft = false;
                current = current.right;
            }
            if (current == null) {
                return;
            }
        }

        if (current.left != null || current.right != null) {
            if (current.right == null) {
                if (current == root) {
                    root = current.left;
                } else if (isInLeft) {
                    parent.left = current.left;
                } else {
                    parent.right = current.left;
                }
            } else if (current.left == null) {
                if (current == root) {
                    root = current.right;
                } else if (isInLeft) {
                    parent.left = current.right;
                } else {
                    parent.right = current.right;
                }
            } else {
                Node temp = current;

                if (current == root) {
                    root = temp;
                } else if (isInLeft) {
                    parent.left = temp;
                } else {
                    parent.right = temp;
                }
                temp.left = current.left;
            }
        } else {
            if (current == root) {
                root = null;
            }
            if (isInLeft) {
                parent.left = null;
            } else {
                parent.right = null;
            }
        }
    }

    public Iterable<K> iterator() {
        return (Iterable<K>) new BinarySearchTreeIterator<K>(this.root);
    }

    class BinarySearchTreeIterator<K extends Comparable<? super K>> implements Iterator<K> {

        private Stack<Node> stack = new Stack<>();
        private Node curr;
        private Node pending;

        BinarySearchTreeIterator(Node root) {
            if (root == null) {
                throw new IllegalArgumentException();
            }
            curr = root;
            while (root != null) {
                stack.push(root);
                root = root.left;
            }
        }

        @Override
        public K next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            pending = stack.pop();
            curr = pending.right;
            while (curr != null) {
                stack.push(curr);
                curr = curr.left;
            }

            return (K) pending.key;
        }

        @Override
        public boolean hasNext() {
            return !stack.isEmpty();
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public static void main(String[] args) {
        BST<Integer, Integer> bst = new BST<>();

        bst.put(10, 5);
        bst.put(4, 2);
        bst.put(2, 1);
        bst.put(12, 6);

        System.out.println(bst.get(10));
        System.out.println(bst.get(4));
        System.out.println(bst.get(2));
        System.out.println(bst.get(12));

        bst.delete(12);
        bst.delete(2);
    }
}
