package second;

import java.util.Arrays;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MyHashTable<K, V> {

    private class HashNode<K, V> {
        private K key;
        private V value;
        private HashNode<K, V> next;

        public HashNode(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return "{" + key + " " + value + "}";
        }
    }

    private HashNode<K, V>[] chainArray;
    private int M = 11;
    private int size;

    public MyHashTable() {
        chainArray = new HashNode[M];
    }

    public MyHashTable(int M) {
        chainArray = new HashNode[M];
        this.M = M;
    }

    private int hash(K key) {
        return Math.abs(key.hashCode()) % M;
    }

    public void put(K key, V value) {
        if (key == null) {
            return;
        }

        int hashedIndex = hash(key);

        if (chainArray[hashedIndex] != null) {
            HashNode<K, V> temp = chainArray[hashedIndex];

            while (temp.next != null) {
                temp = temp.next;
            }

            temp.next = new HashNode<>(key, value);
        } else {
            chainArray[hashedIndex] = new HashNode<>(key, value);
        }

        size++;
    }

    public V get(K key) {
        int hashedIndex = hash(key);

        if (chainArray[hashedIndex] != null) {
            HashNode<K, V> temp = chainArray[hashedIndex];

            while (!temp.key.equals(key) && temp.next != null) { temp = temp.next; }

            return temp.value;
        }

        return null;
    }

    public V remove(K key) {
        int hashedIndex = hash(key);

        if (chainArray[hashedIndex] == null) {
            return null;
        }
        if (chainArray[hashedIndex].key.equals(key)) {
            HashNode<K, V> temp = chainArray[hashedIndex];
            chainArray[hashedIndex] = chainArray[hashedIndex].next;
            size--;
            return temp.value;
        }

        HashNode<K, V> prev = chainArray[hashedIndex];
        HashNode<K, V> curr = prev.next;

        while (curr != null && !curr.key.equals(key)) {
            curr = curr.next;
            prev = curr;
        }

        if (curr != null) {
            prev.next = curr.next;
            size--;
        }

        return null;
    }

    public boolean contains(V value) {
        return IntStream
                .iterate(chainArray.length - 1, i -> i > 0, i -> i - 1)
                .mapToObj(i -> Stream.iterate(chainArray[i], Objects::nonNull, element -> element.next))
                .flatMap(Function.identity())
                .anyMatch(element -> element.value.equals(value));
    }

    public K getKey(V value) {
        return Arrays
                .stream(chainArray)
                .filter(node -> node.value.equals(value))
                .findFirst()
                .map(node -> node.key)
                .orElse(null);

    }

    public static void main(String[] args) {
        MyHashTable<Integer, Integer> hashTable = new MyHashTable<>();

        hashTable.put(1, 10);
        hashTable.put(2, 20);
        hashTable.put(3, 33);
        hashTable.put(5, 2);
        hashTable.put(6, 3);

        System.out.println(hashTable.getKey(2));
        System.out.println(hashTable.get(5));
        System.out.println(hashTable.contains(4));
        hashTable.remove(3);
    }
}
